const $ = s => document.querySelector(s);
const esc = s =>
  String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = n => Number(n || 0).toLocaleString("fr-FR"),
  fm = n => {
    n = +n || 0;
    return n >= 1e9
      ? (n / 1e9).toFixed(1).replace(".", ",") + " Md"
      : n >= 1e6
        ? Math.round(n / 1e6) + " M"
        : n >= 1e3
          ? Math.round(n / 1e3) + " k"
          : String(n);
  },
  nm = v => {
    const p = Math.pow(10, Math.floor(Math.log10(v))),
      m = v / p;
    return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 5 ? 5 : 10) * p;
  },
  fd = d => new Date(d + "T00:00").toLocaleDateString("fr-FR", { weekday: "short", day: "numeric", month: "short" }),
  fdt = t => new Date(t).toLocaleString("fr-FR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }),
  dt = () => {
    const n = new Date();
    return (
      n.toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) +
      "<br>" +
      n.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })
    );
  };
const T = new Date().toISOString().slice(0, 10),
  Y = new Date().getFullYear();
const URLS = "https://aiqegpijisspankpkwfj.supabase.co",
  KEY = "sb_publishable__Zc0adl_eD_PyMkaR5ACzA_-_yjwmbI",
  TS_KEY = "0x4AAAAAAF7OVwUkBsAvSANV";
const sb = supabase.createClient(URLS, KEY, { auth: { storageKey: "mc-cab" } });
window.tsReady = () => {
  if (!S.role) render();
};
const MS = ["\u00c0 r\u00e9pondre", "\u00c0 signer", "Urgent", "Suivi", "Class\u00e9"],
  MC = ["a_repondre", "a_signer", "urgent", "suivi", "classe"],
  RS = [
    "Nouvelle",
    "Orient\u00e9e",
    "En traitement",
    "En validation",
    "Trait\u00e9e",
    "R\u00e9orient\u00e9e",
    "En attente de pi\u00e8ces",
    "Rejet\u00e9e",
    "Cl\u00f4tur\u00e9e",
    "Accept\u00e9e",
    "Pr\u00eat \u00e0 retirer"
  ],
  RC = [
    "nouvelle",
    "orientee",
    "en_cours",
    "a_valider",
    "traitee",
    "redirigee",
    "en_attente_pieces",
    "rejetee",
    "cloturee",
    "acceptee",
    "pret_a_retirer"
  ],
  PS = ["brouillon", "valider", "planifie", "publie"],
  PL = ["Brouillon", "\u00c0 valider", "Planifi\u00e9", "Publi\u00e9"];
const PST = ["programme", "en_cours", "en_attente", "en_retard", "termine", "suspendu"],
  PSL = {
    programme: "Programm\u00e9s",
    en_cours: "En cours",
    en_attente: "En attente",
    en_retard: "En retard",
    termine: "Termin\u00e9s",
    suspendu: "Suspendus"
  },
  PSS = {
    programme: "Programm\u00e9",
    en_cours: "En cours",
    en_attente: "En attente",
    en_retard: "En retard",
    termine: "Termin\u00e9",
    suspendu: "Suspendu"
  },
  PCOL = {
    termine: "#16A34A",
    en_cours: "#2563EB",
    programme: "#F59E0B",
    en_attente: "#94A3B8",
    en_retard: "#DC2626",
    suspendu: "#6B7280"
  },
  TC2 = { termine: "ok", en_cours: "bl", programme: "or", en_attente: "or", en_retard: "rd", suspendu: "" };
const CAT = ["\u00c9ducation", "Sant\u00e9", "Infrastructures", "Autres"],
  CCOL = { "\u00c9ducation": "#2563EB", "Sant\u00e9": "#16A34A", Infrastructures: "#F59E0B", Autres: "#8B5CF6" };
const MOIS = ["Jan", "F\u00e9v", "Mar", "Avr", "Mai", "Juin", "Juil", "Ao\u00fbt", "Sep", "Oct", "Nov", "D\u00e9c"];
const P = [
  "Au rythme des pirogues, {c} s\u2019\u00e9veille\u2026",
  "{c}, terre de sel et de lumi\u00e8re, o\u00f9 chaque mar\u00e9e raconte nos racines.",
  "Entre mangrove et horizon, {c} tisse son avenir avec patience et fiert\u00e9.",
  "Le soleil se couche sur {c} ; demain, nous b\u00e2tirons encore.",
  "Chaque main tendue \u00e0 {c} est une promesse tenue."
];
const E0 = {
  rem: [],
  pai: [],
  pli: [],
  per: [],
  cg: [],
  mar: [],
  pat: [],
  cd: [],
  com: [],
  dec: [],
  rdv: [],
  mail: [],
  req: [],
  posts: [],
  med: [],
  proj: [],
  fin: [],
  del: [],
  adj: [],
  dl: [],
  ru: [],
  rpa: [],
  ins: [],
  rap: [],
  ms: [],
  nt: [],
  dvues: [],
  an: [],
  act: [],
  dos: [],
  sv: [],
  cn: [],
  se: [],
  pr: [],
  dc: [],
  op: [],
  cr: []
};
let S = {
  cs: [],
  sa: false,
  co: "",
  role: null,
  pr: "",
  view: "dash",
  f: "in",
  tab: { cab: "agenda", com: "pub" },
  dd: null,
  dh: [],
  dp: [],
  sel: {},
  fl: {},
  dch: null,
  adjv: null,
  ed: {},
  hi: [],
  hk: null,
  rd: null,
  ri: null,
  rr: null,
  mo: null,
  au: {},
  mine: null,
  pre: null,
  menu: false,
  err: "",
  tok: "",
  cid: null,
  uid: null,
  email: "",
  db: E0,
  ind: {},
  urls: {},
  ia: [],
  map: null,
  mfa: null
};
const D = () => {
    for (const k in E0) if (!S.db[k]) S.db[k] = [];
    return S.db;
  },
  slug = () => (S.cs.find(c => c.nom == S.co) || { slug: S.co.toLowerCase() }).slug;
const run = async p => {
  const r = await p;
  if (r.error) S.err = r.error.message;
  return r;
};
const AL = ["maire", "adjoint", "cabinet", "secretariat", "finances", "rh", "etat_civil", "technique", "agent", "conseiller"];
const RL = {
  maire: "Maire",
  adjoint: "Adjoint",
  cabinet: "Cabinet",
  secretariat: "Secr\u00e9tariat",
  finances: "Finances",
  rh: "RH",
  etat_civil: "\u00c9tat civil",
  technique: "Technique",
  agent: "Agent",
  conseiller: "Conseiller municipal",
  super_admin: "Super-admin",
  citoyen: "Citoyen",
  admin_mairie: "Admin municipal"
};
const RLH = {
  maire: "Monsieur le Maire",
  adjoint: "Monsieur l\u2019Adjoint",
  cabinet: "Cabinet du Maire",
  secretariat: "Secr\u00e9tariat",
  finances: "Service des finances",
  rh: "Service RH",
  etat_civil: "Service de l\u2019\u00e9tat civil",
  technique: "Service technique",
  agent: "Agent municipal",
  conseiller: "Conseiller municipal",
  super_admin: "Administrateur",
  admin_mairie: "Administrateur municipal"
};
const RP = {
  sdash: ["maire"],
  cin: ["maire"],
  cout: ["maire"],
  actes: ["maire"],
  sconseil: ["maire"],
  sinstr: ["maire"],
  serv: ["maire"],
  sreun: ["maire"],
  dossiers: ["maire"],
  archives: ["maire"],
  srap: ["maire"],
  snotif: ["maire"],
  adjdash: ["maire"],
  adjlist: ["maire"],
  deleg: ["maire"],
  projA: ["maire"],
  reun: ["maire"],
  instr: ["maire"],
  rapp: ["maire"],
  msg: ["maire"],
  docs: ["maire"],
  notif: ["maire"],
  cabinet: ["maire", "cabinet", "secretariat"],
  budget: ["maire", "finances"],
  civil: ["maire", "adjoint", "cabinet", "secretariat", "agent", "etat_civil"],
  personnel: ["maire", "rh"],
  params: ["maire"],
  projets: ["maire", "adjoint", "technique", "cabinet"],
  territoire: ["maire", "adjoint", "technique"],
  conseil: ["maire", "adjoint", "cabinet", "secretariat"],
  citoyens: ["maire", "adjoint", "cabinet", "secretariat", "agent", "etat_civil", "technique", "finances", "rh"],
  pub: ["maire", "cabinet", "secretariat"],
  med: ["maire", "cabinet", "secretariat"],
  rapports: ["maire", "adjoint", "cabinet", "finances"]
};
const can = k =>
  S.sa ||
  (k == "cabinet" && (S.mod || {}).cabinet === false
    ? false
    : S.pu && k in S.pu
      ? S.pu[k]
      : S.pm && S.pr + "." + k in S.pm
        ? S.pm[S.pr + "." + k]
        : (RP[k] || []).includes(S.pr) || (typeof orgCan == "function" && orgCan(k)));
const SP0 = {
  adjoints: {
    v: "s_adj",
    n: "Adjoints au Maire",
    i: "users",
    c: "k4",
    d: "D\u00e9l\u00e9gations, instructions, rapports",
    subs: [
      ["adjdash", "Tableau de bord"],
      ["adjlist", "Adjoints"],
      ["deleg", "D\u00e9l\u00e9gations"],
      ["projA", "Projets suivis"],
      ["reun", "R\u00e9unions"],
      ["instr", "Instructions"],
      ["rapp", "Rapports re\u00e7us"],
      ["msg", "Messagerie"],
      ["docs", "Documents"],
      ["notif", "Notifications"]
    ]
  },
  secretariat: {
    v: "s_sec",
    n: "Secr\u00e9tariat municipal",
    i: "mail",
    c: "k2",
    d: "Courrier, actes, conseil, archives",
    subs: [
      ["sdash", "Tableau de bord"],
      ["cin", "Courrier entrant"],
      ["cout", "Courrier sortant"],
      ["actes", "Actes"],
      ["sconseil", "Conseil municipal"],
      ["sinstr", "Instructions"],
      ["serv", "Services"],
      ["sreun", "R\u00e9unions"],
      ["dossiers", "Dossiers"],
      ["archives", "Archives"],
      ["srap", "Rapports"],
      ["snotif", "Notifications"]
    ]
  },
  finances: {
    v: "s_finances",
    n: "Finances",
    i: "coins",
    c: "k1",
    d: "Budget, recettes, d\u00e9penses",
    subs: [["budget", "Budget et recettes"]]
  },
  administration: {
    v: "s_admin",
    n: "Administration",
    i: "brief",
    c: "k2",
    d: "\u00c9tat civil, personnel, param\u00e8tres",
    subs: [
      ["civil", "\u00c9tat civil"],
      ["personnel", "Personnel"],
      ["params", "Param\u00e8tres"]
    ]
  },
  developpement: {
    v: "s_dev",
    n: "D\u00e9veloppement",
    i: "tools",
    c: "k3",
    d: "Projets, travaux, territoire",
    subs: [
      ["projets", "Projets et travaux"],
      ["territoire", "Territoire et foncier"]
    ]
  },
  conseil: {
    v: "s_conseil",
    n: "Conseil municipal",
    i: "users",
    c: "k4",
    d: "Sessions, d\u00e9lib\u00e9rations",
    subs: [["conseil", "D\u00e9lib\u00e9rations"]]
  },
  citoyens: {
    v: "s_citoyens",
    n: "Citoyens",
    i: "mail",
    c: "k5",
    d: "Demandes, communication, m\u00e9dias",
    subs: [
      ["citoyens", "Demandes"],
      ["pub", "Publications"],
      ["med", "M\u00e9diath\u00e8que"]
    ]
  },
  pilotage: {
    v: "s_pilot",
    n: "Pilotage",
    i: "chart",
    c: "k6",
    d: "Rapports, statistiques",
    subs: [["rapports", "Rapports et statistiques"]]
  }
};
const SP = {
  maire: {
    v: "s_maire",
    n: "Espace du Maire",
    i: "user",
    c: "k6",
    d: "Agenda, validations, d\u00e9cisions",
    subs: [
      ["mdash", "Mon tableau de bord"],
      ["agenda", "Agenda"],
      ["aud", "Audiences"],
      ["reun", "R\u00e9unions et activit\u00e9s"],
      ["valid", "\u00c0 valider et \u00e0 signer"],
      ["instr", "Instructions aux adjoints"],
      ["rapp", "Rapports des adjoints"],
      ["msg", "Messagerie"],
      ["notif", "Notifications"],
      ["decis", "Mes d\u00e9cisions"]
    ]
  },
  finances: {
    v: "s_finances",
    n: "Finances",
    i: "coins",
    c: "k1",
    d: "Budget, march\u00e9s, rapports",
    subs: [
      ["budget", "Budget et recettes"],
      ["marches", "March\u00e9s publics"],
      ["rapb", "Rapports budg\u00e9taires"],
      ["paie", "Paie du personnel"],
      ["remun", "R\u00e9mun\u00e9rations"]
    ]
  },
  administration: {
    v: "s_admin",
    n: "Administration",
    i: "brief",
    c: "k2",
    d: "Courrier, actes, personnel, patrimoine",
    subs: [
      ["civil", "\u00c9tat civil"],
      ["personnel", "Personnel"],
      ["conges", "Cong\u00e9s et absences"],
      ["cin", "Courrier entrant"],
      ["cout", "Courrier sortant"],
      ["actes", "Actes administratifs"],
      ["patrimoine", "Patrimoine"],
      ["serv", "Services"],
      ["adjlist", "Adjoints"],
      ["deleg", "D\u00e9l\u00e9gations"],
      ["dossiers", "Dossiers"],
      ["archives", "Archives"],
      ["params", "Param\u00e8tres"]
    ]
  },
  developpement: {
    v: "s_dev",
    n: "D\u00e9veloppement communal",
    i: "tools",
    c: "k3",
    d: "Projets, travaux, territoire",
    subs: [
      ["projets", "Projets et travaux"],
      ["projA", "Suivi par les adjoints"],
      ["devdom", "Par domaine"],
      ["territoire", "Territoire et foncier"]
    ]
  },
  conseil: {
    v: "s_conseil",
    n: "Conseil municipal",
    i: "users",
    c: "k4",
    d: "Sessions, commissions, d\u00e9lib\u00e9rations",
    subs: [
      ["sconseil", "Sessions et d\u00e9lib\u00e9rations"],
      ["conseil", "D\u00e9lib\u00e9rations"],
      ["commissions", "Commissions"]
    ]
  },
  citoyens: {
    v: "s_citoyens",
    n: "Citoyens",
    i: "mail",
    c: "k5",
    d: "Demandes, audiences, communication",
    subs: [
      ["citoyens", "Demandes"],
      ["audc", "Audiences demand\u00e9es"],
      ["recl", "R\u00e9clamations"],
      ["aides", "Aides sociales"],
      ["pub", "Publications"],
      ["med", "M\u00e9diath\u00e8que"]
    ]
  },
  pilotage: {
    v: "s_pilot",
    n: "Pilotage et statistiques",
    i: "chart",
    c: "k6",
    d: "Rapports, indicateurs, d\u00e9cisions",
    subs: [
      ["rapports", "Rapports et statistiques"],
      ["indic", "Indicateurs communaux"],
      ["svcsuivi", "Suivi des services"],
      ["evalproj", "\u00c9valuation des projets"],
      ["decis", "Historique des d\u00e9cisions"]
    ]
  },
  adjoints: Object.assign({}, SP0.adjoints, { h: 1 }),
  secretariat: Object.assign({}, SP0.secretariat, { h: 1 })
};
SP.administration.subs.push(["marchestdb", "March\u00e9s en cours"]);
SP.conseil.subs.push(["suiviconseil", "Suivi des sessions"]);
SP.administration.subs.push(["patbiens", "Biens communaux"]);
const espAll = () =>
  Object.entries(SP)
    .filter(([k, x]) => (S.mod || {})[k] !== false && x.subs.some(y => can(y[0])))
    .map(e => e[1]);
const espV = () => espAll().filter(x => !x.h);
const okv = v =>
  S.sa
    ? SANAV.some(n => n[0] == v)
    : isA()
      ? ANAV.some(n => n[0] == v)
      : isS()
        ? SNAV.some(n => n[0] == v)
        : (typeof amOn == "function" && amOn() && AMNAV.some(n => n[0] == v)) ||
          v == "dash" ||
          (v == "cabinet" ? can("cabinet") : espAll().some(x => x.v == v));
const cmp = (a, b) => (a.d + (a.h || "")).localeCompare(b.d + (b.h || ""));
const IC = {
  home: '<path d="M3 11l9-8 9 8v10h-6v-6H9v6H3z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6z"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><circle cx="17" cy="9" r="2.5"/><path d="M2 20c0-4 3-6 7-6s7 2 7 6zM17 14c3 0 5 1.5 5 5h-4"/>',
  coins:
    '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" fill="none" stroke="currentColor" stroke-width="2"/>',
  tools: '<path d="M14 3l7 7-3 3-7-7zM3 21l8-8 3 3-8 8z"/>',
  brief: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V4h6v3" fill="none" stroke="currentColor" stroke-width="2"/>',
  file: '<path d="M6 2h8l5 5v15H6z"/>',
  map: '<path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7z"/><circle cx="12" cy="9" r="2.5" fill="#fff"/>',
  chart: '<path d="M4 20V10h4v10zM10 20V4h4v16zM16 20v-7h4v7z"/>',
  mega: '<path d="M3 10v4h4l8 5V5L7 10zM18 8c2 1 2 7 0 8"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2l2 3h3l1 3 3 2-1 3 1 3-3 2-1 3h-3l-2 3-2-3H7l-1-3-3-2 1-3-1-3 3-2 1-3h3z" fill="none" stroke="currentColor" stroke-width="2"/>',
  out: '<path d="M4 3h9v4M4 3v18h9v-4M10 12h11M17 8l4 4-4 4" fill="none" stroke="currentColor" stroke-width="2"/>',
  bell: '<path d="M6 17V11a6 6 0 0 1 12 0v6l2 2H4zM10 21h4"/>',
  check: '<circle cx="12" cy="12" r="10" fill="#16A34A"/><path d="M7 12l3.5 3.5L17 9" fill="none" stroke="#fff" stroke-width="2.5"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2" fill="#2563EB"/><path d="M3 7l9 7 9-7" fill="none" stroke="#fff" stroke-width="2"/>',
  doc: '<path d="M6 2h8l5 5v15H6z"/><path d="M9 12h7M9 16h7" stroke="#fff" stroke-width="2"/>',
  alert: '<circle cx="12" cy="12" r="10" fill="#DC2626"/><path d="M12 7v6M12 16v2" stroke="#fff" stroke-width="2.5"/>',
  info: '<circle cx="12" cy="12" r="10" fill="#2563EB"/><path d="M12 11v6M12 7v2" stroke="#fff" stroke-width="2.5"/>',
  cal: '<rect x="3" y="5" width="18" height="16" rx="2" fill="#F59E0B"/><path d="M3 10h18M8 3v4M16 3v4" stroke="#fff" stroke-width="2"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16" fill="none" stroke="currentColor" stroke-width="2.5"/>',
  trend:
    '<path d="M3 17l6-6 4 4 8-9" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M3 21h18" stroke="currentColor" stroke-width="2"/>',
  pie: '<path d="M12 3a9 9 0 1 0 9 9h-9z"/><path d="M14 2a8 8 0 0 1 8 8h-8z"/>',
  shield: '<path d="M12 2l9 3v6c0 5-4 9-9 11C7 20 3 16 3 11V5z" fill="#F2B705" stroke="#fff" stroke-width="1.5"/>'
};
const ic = (n, s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">${IC[n] || ""}</svg>`;
async function lcm() {
  S.cs = (await sb.from("communes").select("id,slug,nom").order("nom")).data || S.cs;
}
async function exigerMfaSuperAdmin() {
  const a = await sb.auth.mfa.getAuthenticatorAssuranceLevel();
  if (a.error) {
    S.mfa = { setup: true };
    S.err = "Vérification MFA indisponible. Réessayez ou contactez l’administrateur.";
    return false;
  }
  if (a.data && a.data.currentLevel === "aal2") {
    S.mfa = null;
    return true;
  }
  const fs = await sb.auth.mfa.listFactors();
  if (fs.error) {
    S.mfa = { setup: true };
    S.err = "Impossible de vérifier le facteur MFA de ce compte.";
    return false;
  }
  const ts = (fs.data && fs.data.totp) || [];
  const f = ts.find(x => x.status === "verified");
  if (!f) {
    for (const pending of ts)
      if (pending.status !== "verified") {
        const r = await sb.auth.mfa.unenroll({ factorId: pending.id });
        if (r.error) {
          S.mfa = { setup: true };
          S.err = "Impossible de renouveler le facteur MFA en attente.";
          return false;
        }
      }
    const e = await sb.auth.mfa.enroll({ factorType: "totp" });
    if (e.error) {
      S.mfa = { setup: true };
      S.err = "Impossible de configurer le facteur TOTP. Contactez l’administrateur.";
      return false;
    }
    S.mfa = { setup: true, factorId: e.data.id, qr: e.data.totp.qr_code, secret: e.data.totp.secret };
    S.err = "Scannez le QR code avec votre application d’authentification, puis confirmez le code à 6 chiffres.";
    return false;
  }
  S.mfa = { factorId: f.id, challengeId: null };
  const ch = await sb.auth.mfa.challenge({ factorId: f.id });
  if (ch.error) {
    S.err = "Impossible de lancer le défi MFA. Vous pouvez réessayer.";
    return false;
  }
  S.mfa.challengeId = ch.data.id;
  S.err = "";
  return false;
}
async function profil() {
  const u = (await sb.auth.getUser()).data.user;
  if (!u) {
    S.err = "Connexion impossible : session introuvable. Réessayez.";
    return false;
  }
  Object.keys(SGN).forEach(k => delete SGN[k]);
  S.uid = u.id;
  S.email = u.email || "";
  const p = (await sb.from("profiles").select("role,commune_id,actif").eq("id", u.id).maybeSingle()).data;
  if (!p || p.actif === false || !AL.concat("super_admin", "admin_mairie").includes(p.role)) {
    S.err = "Ce compte n’a pas encore accès à l’espace mairie. Contactez l’administrateur.";
    await sb.auth.signOut();
    return false;
  }
  /* Double authentification (TOTP) obligatoire pour le super admin ET les admins municipaux (accès aux comptes et aux données de la mairie). */
  if ((p.role === "super_admin" || p.role === "admin_mairie") && !(await exigerMfaSuperAdmin())) return false;
  await lcm();
  const c = S.cs.find(x => x.id == p.commune_id) || (p.role == "super_admin" ? S.cs[0] : null);
  if (!c) {
    S.err = "Aucune commune n\u2019est associ\u00e9e \u00e0 ce compte. Contactez l\u2019administrateur.";
    await sb.auth.signOut();
    return false;
  }
  await loadSys(c.id);
  if (
    ((S.sys.maintenance || {}).actif && p.role != "super_admin") ||
    (p.role == "adjoint" && S.mod.portail_adjoint === false) ||
    (p.role == "secretariat" && S.mod.portail_secretariat === false)
  ) {
    S.err = (S.sys.maintenance || {}).actif
      ? (S.sys.maintenance || {}).message || "L\u2019application est en maintenance. R\u00e9essayez plus tard."
      : "Ce module est d\u00e9sactiv\u00e9 par l\u2019administrateur.";
    await sb.auth.signOut();
    return false;
  }
  S.sa = p.role == "super_admin";
  S.pr = p.role;
  S.co = c ? c.nom : "";
  S.cid = c ? c.id : null;
  S.role = "cab";
  S.view =
    p.role == "super_admin"
      ? "sa_dash"
      : p.role == "adjoint"
        ? "a_dash"
        : p.role == "secretariat"
          ? "s_dash"
          : p.role == "admin_mairie"
            ? "am_dash"
            : "dash";
  S.menu = false;
  LOGIN_AT = Date.now();
  return true;
}
const SGN = {};
async function sign(bk, paths) {
  const now = Date.now(),
    k = p => bk + "|" + p,
    need = [...new Set(paths)].filter(p => !(SGN[k(p)] && SGN[k(p)].t > now));
  for (let i = 0; i < need.length; i += 100) {
    const r = (await sb.storage.from(bk).createSignedUrls(need.slice(i, i + 100), 3600)).data || [];
    r.forEach(x => {
      if (x.signedUrl) SGN[k(x.path)] = { u: x.signedUrl, t: now + 3300000 };
    });
  }
  const o = {};
  paths.forEach(p => {
    const c = SGN[k(p)];
    if (c) o[p] = c.u;
  });
  return o;
}
const LQ = t => sb.from(t).select("*").eq("commune_id", S.cid),
  DE = { ascending: false },
  AS_ = (t, o) => () => LQ(t).order(o, DE),
  SL_ = (t, k) => [
    () => sb.from(t).select("*"),
    r => {
      S.db[k] = r || [];
    }
  ];
const LG = {
  rdv: [
    () => LQ("rdv").order("jour").order("heure"),
    r => {
      S.db.rdv = (r || []).map(x => ({ id: x.id, d: x.jour, h: x.heure.slice(0, 5), t: x.titre }));
    }
  ],
  courrier: [
    AS_("courrier", "created_at"),
    r => {
      r = r || [];
      S.db.cr = r;
      S.db.mail = r.map(x => ({
        id: x.id,
        s: x.sens,
        f: x.correspondant,
        o: x.objet,
        st: MS[MC.indexOf(x.statut)] || CSL[x.statut] || x.statut
      }));
    }
  ],
  demandes: [
    AS_("demandes", "created_at"),
    r => {
      S.db.req = (r || []).map(x => ({
        id: x.id,
        n: x.numero,
        t: x.type,
        w: x.nom,
        m: x.message,
        st: RS[RC.indexOf(x.statut)],
        c: x.created_at,
        o: x.objet,
        ct: x.contact,
        tel: x.telephone,
        sv: x.service,
        rp: x.reponse,
        pd: x.pieces_demandees,
        mr: x.motif_rejet,
        pc: x.pieces || []
      }));
    }
  ],
  publications: [
    () => LQ("publications").order("jour"),
    r => {
      S.db.posts = (r || []).map(x => ({ id: x.id, r: x.reseau, d: x.jour, t: x.texte, st: x.statut, m: x.media_id }));
    }
  ],
  medias: [
    AS_("medias", "created_at"),
    r => {
      S.db.med = (r || []).map(x => ({ id: x.id, ty: x.type, t: x.titre, p: x.chemin, u: x.url, src: "" }));
    }
  ],
  projets: [
    AS_("projets", "created_at"),
    r => {
      S.db.proj = r || [];
    }
  ],
  finances: [
    () => LQ("finances").eq("annee", Y).order("mois"),
    r => {
      S.db.fin = r || [];
    }
  ],
  deliberations: [
    AS_("deliberations", "jour"),
    r => {
      S.db.del = r || [];
    }
  ],
  indicateurs: [
    () => sb.from("indicateurs").select("*").eq("commune_id", S.cid).maybeSingle(),
    r => {
      S.ind = r || {};
    }
  ],
  adjoints: [
    () => LQ("adjoints").order("rang"),
    r => {
      S.db.adj = r || [];
    }
  ],
  delegations: [
    AS_("delegations", "created_at"),
    r => {
      S.db.dl = r || [];
    }
  ],
  reunions: [
    () => LQ("reunions").order("jour").order("heure"),
    r => {
      S.db.ru = r || [];
    }
  ],
  reunion_participants: SL_("reunion_participants", "rpa"),
  instructions: [
    AS_("instructions", "created_at"),
    r => {
      S.db.ins = r || [];
    }
  ],
  rapports: [
    AS_("rapports", "created_at"),
    r => {
      S.db.rap = r || [];
    }
  ],
  messages: [
    () => sb.from("messages").select("*").order("created_at", DE).limit(100),
    r => {
      S.db.ms = r || [];
    }
  ],
  /* Demandes déjà consultées par cet utilisateur (serveur, partagé entre ses appareils). Tolérant : table absente ou erreur => liste vide, aucun message d'erreur. 999 lignes max (pas de pagination). */
  dvues: [
    () =>
      sb
        .from("demandes_vues")
        .select("demande_id")
        .order("vu_le", DE)
        .limit(999)
        .then(
          r => (r.error ? { data: [] } : r),
          () => ({ data: [] })
        ),
    r => {
      S.db.dvues = r || [];
    }
  ],
  notifications: [
    () => sb.from("notifications").select("*").order("created_at", DE).limit(60),
    r => {
      S.db.nt = r || [];
    }
  ],
  annuaire: [
    () => sb.rpc("annuaire"),
    r => {
      S.db.an = r || [];
    }
  ],
  actes: [
    AS_("actes", "created_at"),
    r => {
      S.db.act = r || [];
    }
  ],
  dossiers: [
    AS_("dossiers", "created_at"),
    r => {
      S.db.dos = r || [];
    }
  ],
  services: [
    () => LQ("services").order("nom"),
    r => {
      S.db.sv = r || [];
    }
  ],
  conseillers: [
    () => LQ("conseillers").order("nom"),
    r => {
      S.db.cn = r || [];
    }
  ],
  sessions_conseil: [
    AS_("sessions_conseil", "jour"),
    r => {
      S.db.se = r || [];
    }
  ],
  session_presences: SL_("session_presences", "pr"),
  documents: [
    () => LQ("documents").order("created_at", DE).limit(500),
    r => {
      S.db.dc = r || [];
    }
  ],
  remunerations: [
    () => LQ("remunerations"),
    r => {
      S.db.rem = r || [];
    }
  ],
  paies: [
    () => LQ("paies").order("mois", DE),
    r => {
      S.db.pai = r || [];
    }
  ],
  paie_lignes: [
    () => LQ("paie_lignes").limit(500),
    r => {
      S.db.pli = r || [];
    }
  ],
  personnel: [
    () => LQ("personnel").order("nom"),
    r => {
      S.db.per = r || [];
    }
  ],
  conges: [
    AS_("conges", "date_debut"),
    r => {
      S.db.cg = r || [];
    }
  ],
  conges_droits: [
    () => LQ("conges_droits").eq("annee", Y),
    r => {
      S.db.cd = r || [];
    }
  ],
  marches: [
    AS_("marches", "created_at"),
    r => {
      S.db.mar = r || [];
    }
  ],
  patrimoine: [
    AS_("patrimoine", "created_at"),
    r => {
      S.db.pat = r || [];
    }
  ],
  commissions: [
    () => LQ("commissions").order("nom"),
    r => {
      S.db.com = r || [];
    }
  ],
  decisions: [
    AS_("decisions", "jour"),
    r => {
      S.db.dec = r || [];
    }
  ],
  ops_historique: [
    () => sb.from("ops_historique").select("*").order("created_at", DE).limit(60),
    r => {
      S.db.op = r || [];
    }
  ]
};
/* load() = tout recharger ; load(["projets"]) = seulement ces tables (+ notifications et historique) */
async function load(only) {
  if (S.role != "cab" || !S.cid) return;
  const ks = only
    ? [...new Set(only.concat(["notifications", "ops_historique"]))].filter(k => LG[k])
    : Object.keys(LG)
        .filter(
          k => !["personnel", "conges", "conges_droits", "remunerations", "paie_lignes"].includes(k) || ["maire", "rh"].includes(S.pr)
        )
        .filter(k => k != "paies" || ["maire", "rh", "finances"].includes(S.pr));
  if (!only && S.sa) await saLoad();
  const R = await Promise.all(ks.map(k => LG[k][0]()));
  const er = R.find(x => x.error),
    bad = ks.filter((k, i) => R[i].error);
  if (er && bad.length == ks.length) {
    S.err = "Chargement impossible : " + er.error.message + ". Reconnectez-vous si le probl\u00e8me persiste.";
    return;
  }
  if (er) {
    S.err = "Chargement partiel (" + bad.join(", ") + ") : " + er.error.message;
    bad.forEach(k => {
      R[ks.indexOf(k)] = { data: null };
    });
  }
  /* PostgREST plafonne à 1000 lignes : page suivante tant que la page est pleine (10 000 max) */
  for (let i = 0; i < ks.length; i++) {
    const k = ks[i];
    let d = R[i].data;
    if (!Array.isArray(d) || d.length < 1000 || k == "annuaire") continue;
    for (let p = 1; p < 10; p++) {
      const r = await LG[k][0]()
        .order("id")
        .range(p * 1000, p * 1000 + 999);
      if (r.error) {
        S.err = "Chargement partiel de " + k + " : " + r.error.message;
        break;
      }
      d = d.concat(r.data || []);
      if ((r.data || []).length < 1000) break;
      if (p == 9) S.err = "Liste " + k + " tronquée à 10 000 lignes.";
    }
    R[i].data = d;
  }
  if (S.db === E0) S.db = Object.assign({}, E0);
  ks.forEach((k, i) => LG[k][1](R[i].data));
  const d = D(),
    I = S.ind;
  S.mine = (d.adj.find(a => a.user_id == S.uid) || {}).id || null;
  const mp = d.med
      .filter(x => x.ty == "photo")
      .map(x => x.p)
      .concat([I.blason, I.photo_maire, I.bandeau].filter(Boolean)),
    ap = []
      .concat(
        d.adj.map(a => a.photo),
        d.dl.map(x => x.acte),
        d.ins.flatMap(x => x.pieces || []),
        d.rap.flatMap(x => (x.photos || []).concat(x.docs || [])),
        d.proj.flatMap(x => (x.photos || []).concat(x.docs || [])),
        d.ru.flatMap(x => x.docs || [])
      )
      .filter(Boolean);
  const U = await Promise.all([sign("medias", mp), sign("adjoints", ap)]);
  S.urls = U[0];
  S.au = U[1];
  d.med.forEach(m => {
    m.src = S.urls[m.p] || "";
  });
}
const comp = async (f, mx = 1920, tg = 450000) => {
    const im = await createImageBitmap(f);
    let k = Math.min(1, mx / Math.max(im.width, im.height)),
      q = 0.82,
      b;
    for (let n = 0; n < 6; n++) {
      const c = document.createElement("canvas");
      c.width = Math.round(im.width * k);
      c.height = Math.round(im.height * k);
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height);
      b = await new Promise(r => c.toBlob(r, "image/webp", q));
      if (b.type != "image/webp") b = await new Promise(r => c.toBlob(r, "image/jpeg", q));
      if (b.size <= tg) break;
      if (q > 0.7) q -= 0.04;
      else k *= 0.88;
    }
    return b;
  },
  kb = n => (n > 1e6 ? (n / 1e6).toFixed(1) + " Mo" : Math.round(n / 1e3) + " Ko");
const rc = s =>
  ({
    Nouvelle: "or",
    "Orient\u00e9e": "bl",
    "En traitement": "bl",
    "En validation": "or",
    "Trait\u00e9e": "ok",
    "R\u00e9orient\u00e9e": "ok",
    "En attente de pi\u00e8ces": "or",
    "Rejet\u00e9e": "rd",
    "Cl\u00f4tur\u00e9e": "ok",
    "Accept\u00e9e": "ok",
    "Pr\u00eat \u00e0 retirer": "ok"
  })[s] || "";
const mt = p => {
  const m = D().med.find(x => x.id == p.m);
  return m
    ? m.ty == "photo" && m.src
      ? `<img class="th" src="${esc(m.src)}" alt="${esc(m.t)}">`
      : `<div class="mut">Vid\u00e9o : ${esc(m.t)}</div>`
    : "";
};
const url = k => S.urls[S.ind[k]] || "";
/* alertes et activit\u00e9s */
/* Demandes déjà ouvertes : mémorisées par utilisateur et par commune sur cet appareil (aucune donnée personnelle, seulement des identifiants) */
const seenKey = () => "mc_vu_" + (S.uid || "") + "_" + (S.cid || "");
const localSeen = () => {
  try {
    return new Set(JSON.parse(localStorage.getItem(seenKey()) || "[]"));
  } catch (e) {
    return new Set();
  }
};
const serverSeen = () => new Set((D().dvues || []).map(x => x.demande_id));
/* « Vu » = serveur (tous les appareils de l'agent) + mémoire locale (immédiat, et repli si le serveur ne répond pas) */
const seenSet = () => new Set([...localSeen(), ...serverSeen()]);
/* Enregistre côté serveur ; un échec (réseau, fonction non installée) n'a aucune conséquence : la mémoire locale reste valable */
const pushSeen = id => {
  S.vsync = S.vsync || new Set();
  const k = S.uid + ":" + id;
  if (S.vsOff || S.vsync.has(k)) return Promise.resolve();
  S.vsync.add(k);
  let q;
  try {
    q = Promise.resolve(sb.rpc("marquer_demande_vue", { p_demande: id }));
  } catch (e) {
    S.vsync.delete(k);
    return Promise.resolve();
  }
  return q.then(
    r => {
      if (r && r.error) {
        S.vsync.delete(k);
        if (/function|could not find|schema cache|404/i.test(String(r.error.message || r.error.code || ""))) S.vsOff = true;
      } else if (r && r.data === true) D().dvues = (D().dvues || []).concat([{ demande_id: id }]);
    },
    () => S.vsync.delete(k)
  );
};
const markSeen = id => {
  if (!id) return;
  try {
    const s = localSeen();
    if (!s.has(id)) {
      s.add(id);
      const ids = new Set(D().req.map(r => r.id));
      localStorage.setItem(seenKey(), JSON.stringify([...s].filter(x => ids.has(x))));
    }
  } catch (e) {}
  if (!serverSeen().has(id)) pushSeen(id);
};
/* Rattrapage unique : les demandes déjà ouvertes avant cette mise à jour (mémoire locale) sont transmises au serveur, 25 par passage */
const syncSeen = () => {
  if (S.vsOff || !S.uid) return;
  const sv = serverSeen(),
    ids = new Set(D().req.map(r => r.id));
  [...localSeen()]
    .filter(x => ids.has(x) && !sv.has(x))
    .slice(0, 25)
    .forEach(pushSeen);
};
/* Nouvelles demandes que l'utilisateur n'a pas encore ouvertes */
const unseenNew = () => {
  const s = seenSet();
  return D().req.filter(r => r.st == "Nouvelle" && !s.has(r.id));
};
const alerts = () => {
  const d = D(),
    I = S.ind,
    a = [],
    pl = n => (n > 1 ? "s" : "");
  const sg = d.mail.filter(m => m.st == "\u00c0 signer").length;
  if (sg) a.push({ i: "alert", n: sg, t: `${sg} dossier${pl(sg)} en attente de signature` });
  const nv = unseenNew().length;
  if (nv) a.push({ i: "info", n: nv, t: `${nv} nouvelle${pl(nv)} demande${pl(nv)} citoyenne${pl(nv)} \u00e0 consulter` });
  const pv = d.posts.filter(p => p.st == "valider").length;
  if (pv) a.push({ i: "info", n: pv, t: `${pv} publication${pl(pv)} \u00e0 valider` });
  const dp = d.fin.reduce((s, r) => s + +r.depenses, 0);
  if (I.budget_annuel && dp > I.budget_annuel) a.push({ i: "alert", n: 1, t: "Budget : les d\u00e9penses d\u00e9passent le budget annuel" });
  const nx = d.rdv.filter(r => r.d >= T).sort(cmp)[0];
  if (nx) a.push({ i: "cal", t: `Prochain rendez-vous : ${nx.t} (${fd(nx.d)})` });
  return a;
};
const acts = () => {
  const d = D();
  return [
    ...d.req.slice(0, 4).map(r => ({ t: r.c, i: "mail", a: "Nouvelle demande citoyenne", b: r.t + " \u2014 " + r.w })),
    ...d.del.slice(0, 4).map(x => ({ t: x.created_at, i: "doc", a: "D\u00e9lib\u00e9ration n\u00b0" + x.numero, b: x.objet })),
    ...d.proj.slice(0, 4).map(p => ({ t: p.created_at, i: "check", a: "Projet : " + p.titre, b: "Avancement : " + p.avancement + "%" }))
  ]
    .sort((a, b) => String(b.t).localeCompare(String(a.t)))
    .slice(0, 4);
};
/* graphiques */
const lineC = rows => {
  if (!rows.length)
    return emp("Aucune donn\u00e9e financi\u00e8re. Ajoutez les recettes et d\u00e9penses du mois dans Budget et Finances.");
  const W = 520,
    H = 230,
    L = 54,
    R = 14,
    Tp = 16,
    B = 30,
    top = nm(Math.max(1, ...rows.flatMap(r => [+r.recettes, +r.depenses]))),
    x = i => L + (rows.length < 2 ? (W - L - R) / 2 : (i * (W - L - R)) / (rows.length - 1)),
    y = v => Tp + (H - Tp - B) * (1 - v / top);
  let g = "";
  for (let k = 0; k <= 4; k++) {
    const v = (top * k) / 4;
    g += `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="#E5E7EB"/><text x="${L - 8}" y="${y(v) + 4}" text-anchor="end" font-size="12" fill="#4B5563">${fm(v)}</text>`;
  }
  const ln = (k, c) =>
    `<path d="${rows.map((r, i) => (i ? "L" : "M") + x(i) + "," + y(+r[k])).join("")}" fill="none" stroke="${c}" stroke-width="3"/>` +
    rows.map((r, i) => `<circle cx="${x(i)}" cy="${y(+r[k])}" r="4.5" fill="${c}"/>`).join("");
  return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Recettes et d\u00e9penses par mois">${g}${rows.map((r, i) => `<text x="${x(i)}" y="${H - 8}" text-anchor="middle" font-size="12" fill="#4B5563">${MOIS[r.mois - 1]}</text>`).join("")}${ln("recettes", "#16A34A")}${ln("depenses", "#2563EB")}</svg><div class="lgd"><span><i data-sty="background:#16A34A"></i>Recettes</span><span><i data-sty="background:#2563EB"></i>D\u00e9penses</span></div>`;
};
const donut = (segs, c1, c2) => {
  const tot = segs.reduce((s, x) => s + x.v, 0) || 1,
    R = 52,
    C = 2 * Math.PI * R;
  let o = 0;
  return `<svg viewBox="0 0 140 140" role="img"><circle cx="70" cy="70" r="${R}" fill="none" stroke="#E5E7EB" stroke-width="20"/>${segs
    .map(s => {
      const l = (s.v / tot) * C,
        e = `<circle cx="70" cy="70" r="${R}" fill="none" stroke="${s.c}" stroke-width="20" stroke-dasharray="${l} ${C - l}" stroke-dashoffset="${-o}" transform="rotate(-90 70 70)"/>`;
      o += l;
      return e;
    })
    .join(
      ""
    )}<text x="70" y="${c2 ? 68 : 76}" text-anchor="middle" font-size="26" font-weight="800" fill="#14231A">${c1}</text>${c2 ? `<text x="70" y="88" text-anchor="middle" font-size="11" fill="#4B5563">${c2}</text>` : ""}</svg>`;
};
const stat = () => {
  const d = D(),
    I = S.ind,
    rec = d.fin.reduce((s, r) => s + +r.recettes, 0),
    dep = d.fin.reduce((s, r) => s + +r.depenses, 0),
    ex = I.budget_annuel ? Math.round((dep / I.budget_annuel) * 100) : 0,
    pr = d.proj,
    avg = pr.length ? Math.round(pr.reduce((s, p) => s + (p.statut == "termine" ? 100 : +p.avancement), 0) / pr.length) : 0,
    cn = k => pr.filter(p => p.statut == k).length,
    dels = d.del.filter(x => new Date(x.jour).getFullYear() == Y).length;
  return { d, I, rec, dep, ex, pr, avg, cn, dels };
};
const progP = s =>
  `<div class="dn">${donut(
    [
      { v: s.avg, c: "#16A34A" },
      { v: 100 - s.avg, c: "#E5E7EB" }
    ],
    s.avg + "%"
  )}<div data-sty="flex:1;min-width:130px">${PST.slice()
    .reverse()
    .map(
      k =>
        `<div class="rw" data-sty="padding:6px 0"><span><i data-sty="display:inline-block;width:11px;height:11px;border-radius:50%;background:${PCOL[k]};margin-right:8px"></i>${PSL[k]}</span><b>${s.cn(k)}</b></div>`
    )
    .join(
      ""
    )}</div></div><p data-sty="text-align:center;font-weight:800;margin:6px 0 0">${s.pr.length} projet${s.pr.length > 1 ? "s" : ""} au total</p>`;
const invP = s => {
  const t = s.pr.reduce((a, p) => a + +p.budget, 0);
  if (!t) return emp("Renseignez le budget des projets pour voir la r\u00e9partition.");
  const by = CAT.map(c => ({ k: c, v: s.pr.filter(p => p.categorie == c).reduce((a, p) => a + +p.budget, 0), c: CCOL[c] }));
  return `<div class="dn">${donut(by, fm(t), "FCFA")}<div data-sty="flex:1;min-width:130px">${by.map(b => `<div class="rw" data-sty="padding:6px 0"><span><i data-sty="display:inline-block;width:11px;height:11px;border-radius:50%;background:${b.c};margin-right:8px"></i>${b.k}</span><b>${Math.round((b.v / t) * 100)}%</b></div>`).join("")}</div></div>`;
};
const mapP = xl =>
  `<div id="map" class="map${xl ? " xl" : ""}"></div><div class="lgd">${PST.map(k => `<span><i data-sty="background:${PCOL[k]}"></i>${PSL[k]}</span>`).join("")}</div>`;
function initMap() {
  const el = $("#map");
  if (!el) return;
  const I = S.ind || {},
    ps = D().proj.filter(p => p.lat != null && p.lng != null);
  S.map = mapbox3d(el, {
    centre: I.centre_lng != null && I.centre_lat != null ? [I.centre_lng, I.centre_lat] : null,
    zoom: I.zoom || 0,
    fitMax: 13,
    one: 13,
    pts: ps.map(p => ({ lat: p.lat, lng: p.lng, c: PCOL[p.statut], l1: p.titre, l2: p.localite || "", l3: PSL[p.statut] + " : " + p.avancement + "%" }))
  });
}
/* coque */
/* Pastille de la cloche : nombre d'éléments à traiter (pas de catégories) ; l'information « prochain rendez-vous » ne compte pas */
const badgeN = () => alerts().reduce((s, x) => s + (x.n || 0), 0) + D().nt.filter(n => !n.lu).length;
/* Met à jour la pastille sans refaire l'écran (aucune perte de saisie) */
const majBadge = () => {
  const b = document.querySelector(".tb .bl");
  if (!b) return;
  const n = badgeN();
  let e = b.querySelector("b");
  if (n) {
    if (!e) {
      e = document.createElement("b");
      b.appendChild(e);
    }
    e.textContent = n;
  } else if (e) e.remove();
};
const tb = t => {
  const nb = badgeN();
  return `<div class="tb"><button class="mb" data-a="menu" aria-label="Menu">${ic("menu", 26)}</button>${t ? `<h1 class="tt">${t}</h1>` : "<span></span>"}<div class="tr"><div class="dc">${ic("cal", 22)}<div>${dt()}</div></div><button class="bl" ${S.pr == "maire" && !S.sa ? 'data-m="go" data-sp="maire" data-t="notif"' : `data-a="go" data-v="${isA() ? "a_notif" : isS() ? "s_notif" : "dash"}"`} aria-label="Notifications">${ic("bell", 24)}${nb ? `<b>${nb}</b>` : ""}</button><div class="av" title="${esc(S.email)}">${esc((S.email || "?")[0])}</div></div></div>`;
};
const page = (t, b) =>
  S.inS ? b : `<div class="tbw">${tb(t)}</div><div class="ct">${S.err ? `<div class="al" role="alert">${esc(S.err)}</div>` : ""}${b}</div>`;
const NAV = () => {
  if (S.sa) return SANAV;
  if (isA()) return ANAV;
  if (isS()) return SNAV;
  const n = [["dash", "Accueil", "home"]];
  if (can("cabinet") && S.pr != "maire") n.push(["cabinet", "Cabinet du Maire", "user"]);
  espV().forEach(x => n.push([x.v, x.n, x.i]));
  return typeof amOn == "function" && amOn() ? AMNAV.concat(n) : n;
};
const brand = () =>
  `<div class="br">${url("blason") ? `<img src="${esc(url("blason"))}" alt="Blason">` : ic("shield", 86)}<div class="bn">MAIRIE DE ${esc((S.co || "").toUpperCase())}</div><div class="bs">${esc(S.ind.slogan || "")}</div></div>`;
const palms =
  '<svg class="pm" viewBox="0 0 1000 110" preserveAspectRatio="xMidYMin slice" aria-hidden="true"><defs><g id="p"><path d="M30 110c2-30 0-55-4-80" stroke="#6B4A2B" stroke-width="4" fill="none"/><path d="M26 30C14 20 6 26 0 38c10-6 18-6 26-8zM26 30c4-14 18-18 32-10-12 0-20 4-30 10zM26 30c-6-12-4-22 4-26-2 10 0 18 0 26z" fill="#2F8F3E"/></g></defs><g opacity=".85"><use href="#p" x="20"/><use href="#p" x="150" y="10"/><use href="#p" x="300"/><use href="#p" x="430" y="14"/><use href="#p" x="580"/><use href="#p" x="720" y="8"/><use href="#p" x="860"/><use href="#p" x="940" y="14"/></g></svg>';
/* Accueil adapté au poste : phrase d'accroche et module prioritaire (l'interface reste unique, chacun ne voit que ses droits) */
const RSUB = {
    cabinet: "Agenda, courrier et relations avec les citoyens",
    finances: "Budget, march\u00e9s et suivi financier",
    rh: "Personnel, cong\u00e9s et paie",
    etat_civil: "Actes et demandes d\u2019\u00e9tat civil",
    technique: "Projets, travaux et patrimoine",
    agent: "Demandes \u00e0 traiter et \u00e9tat civil"
  },
  RPRI = { finances: "s_finances", rh: "s_admin", etat_civil: "s_admin", agent: "s_admin", technique: "s_dev", cabinet: "s_citoyens" };
const dash = () => {
  const s = stat(),
    I = s.I,
    bg = url("bandeau")
      ? `data-sty="background-image:linear-gradient(rgba(255,255,255,.1),rgba(243,246,241,.9)),url('${esc(url("bandeau"))}')"`
      : "",
    ph = url("photo_maire")
      ? `<img class="mp" src="${esc(url("photo_maire"))}" alt="Photo du responsable">`
      : `<div class="mp" aria-hidden="true">${esc((S.co || "M")[0])}</div>`;
  const al = alerts(),
    ac = acts(),
    who = S.sa ? RLH.super_admin : RLH[S.pr] || "Monsieur le Maire",
    fin = can("budget"),
    prj = can("projets"),
    cards = (
      can("cabinet") && S.pr != "maire" ? [{ v: "cabinet", n: "Cabinet du Maire", i: "user", c: "k6", d: "Agenda et courrier" }] : []
    ).concat(espV());
  if (RPRI[S.pr]) cards.sort((a, b) => (b.v == RPRI[S.pr]) - (a.v == RPRI[S.pr]));
  return `<div class="hero" ${bg}>${url("bandeau") ? "" : palms}${tb("")}<div class="gr">${ph}<div><h1>Bonjour, ${esc(who)}</h1><i>${esc(!S.sa && RSUB[S.pr] ? RSUB[S.pr] : "Voici la situation g\u00e9n\u00e9rale de votre commune")}</i></div></div></div><div class="ct">${S.err ? `<div class="al" role="alert">${esc(S.err)}</div>` : ""}
${
  al.length
    ? `<div class="as" role="region" aria-label="Alertes importantes">${al
        .slice(0, 4)
        .map(a => `<div class="ai">${ic(a.i, 24)}<b>${esc(a.t)}</b></div>`)
        .join("")}</div>`
    : ""
}
<div class="ecg">${cards.map(x => `<button class="ec ${x.c}" data-a="go" data-v="${x.v}">${ic(x.i, 28)}<b>${x.n}</b><span>${x.d}</span></button>`).join("")}</div>
<div class="kp">${kp("k1", "users", "Population", fmt(I.population), I.croissance ? `${I.croissance > 0 ? "\u25b2 +" : "\u25bc "}${I.croissance}%` : "")}${kp("k2", "home", "Villages &amp; Localit\u00e9s", fmt(I.villages))}${kp("k3", "home", "M\u00e9nages recens\u00e9s", fmt(I.menages))}${kp("k4", "users", "Agents municipaux", fmt(I.agents))}${kp("k5", "doc", "D\u00e9lib\u00e9rations " + Y, s.dels)}${fin ? `<div class="kc kb"><div class="kl big">Budget Annuel ${Y}</div><div class="kbv">${ic("coins", 44)}<span>${I.budget_annuel ? fm(I.budget_annuel) + " FCFA" : "\u2014"}</span></div><div class="bar"><i data-sty="width:${Math.min(100, s.ex)}%"></i></div><div class="ks">${s.ex}% ex\u00e9cut\u00e9</div></div>` : ""}</div>
${fin || prj ? `<div class="g3">${fin ? pn("\u00c9volution des Finances", "trend", lineC(s.d.fin)) : ""}${prj ? pn("Avancement des Projets", "pie", progP(s)) : ""}${prj ? pn("Carte de la Commune", "map", mapP()) : ""}</div>` : ""}
<div class="g3">${pn("Activit\u00e9s r\u00e9centes", "tools", ac.map(a => `<div class="rw"><div class="ai">${ic(a.i, 28)}<div><b>${esc(a.a)}</b><div class="mut">${esc(a.b)}</div></div></div><span class="mut" data-sty="font-size:12px;white-space:nowrap">${fdt(a.t)}</span></div>`).join("") || emp("Aucune activit\u00e9 pour le moment."))}${prj ? pn("R\u00e9partition des Investissements", "chart", invP(s)) : ""}</div></div>`;
};
/* vues */
const agenda = () =>
  frm(
    inp("rd", "Date", "date", T) +
      inp("rh", "Heure", "time", "09:00") +
      inp("rt", "Rendez-vous", "text", "", "Intitul\u00e9") +
      `<button class="bt" data-a="addrdv">Ajouter</button>`
  ) +
  (D()
    .rdv.map((r, i) => [r, i])
    .sort((a, b) => cmp(a[0], b[0]))
    .map(([r, i]) => rw(`<b>${esc(r.h)}</b> <span class="mut">${fd(r.d)}</span><div>${esc(r.t)}</div>`, tag("Retirer", "delrdv", i)))
    .join("") || emp("Aucun rendez-vous. Ajoutez le premier ci-dessus."));
const mailv = () =>
  `<div class="tabs"><button class="tb2${S.f == "in" ? " on" : ""}" data-a="filt" data-f="in">Entrant</button><button class="tb2${S.f == "out" ? " on" : ""}" data-a="filt" data-f="out">Sortant</button></div>` +
  frm(
    sel(
      "ms",
      "Type",
      [
        ["in", "Entrant"],
        ["out", "Sortant"]
      ],
      S.f
    ) +
      inp("mf", "Exp\u00e9diteur ou destinataire") +
      inp("mo", "Objet") +
      `<button class="bt" data-a="addmail">Ajouter</button>`
  ) +
  (D()
    .mail.map((m, i) => [m, i])
    .filter(x => x[0].s == S.f)
    .map(([m, i]) =>
      rw(
        `<b>${esc(m.o)}</b><div class="mut">${esc(m.f)}</div>`,
        tag(m.st, "cycm", i, m.st == "Urgent" ? "rd" : m.st == "\u00c0 signer" ? "or" : "")
      )
    )
    .join("") || emp("Aucun courrier dans cette bo\u00eete."));
const SVO = [
    ["secretariat", "Secr\u00e9tariat"],
    ["etat_civil", "\u00c9tat civil"],
    ["technique", "Service technique"],
    ["finances", "Finances"],
    ["rh", "RH"],
    ["maire", "Cabinet du Maire"],
    ["adjoint", "Adjoint"],
    ["externe", "Organisme ext\u00e9rieur"]
  ],
  svn = x => (SVO.find(y => y[0] == x) || [0, x || "\u2014"])[1];
async function openD() {
  const r = D().req.find(x => x.id == S.dd);
  if (!r) {
    S.dh = [];
    S.dp = [];
    return;
  }
  S.dh = (await sb.from("demande_historique").select("*").eq("demande_id", r.id).order("created_at")).data || [];
  S.dp = r.pc.length
    ? ((await sb.storage.from("pieces").createSignedUrls(r.pc, 3600)).data || []).map(x => x.signedUrl).filter(Boolean)
    : [];
}
const dpanel = r => {
  const o = ["maire", "adjoint", "cabinet", "secretariat"].includes(S.pr) || S.sa,
    v = ["maire", "adjoint"].includes(S.pr) || S.sa;
  return `<div class="pn" data-sty="border:2px solid var(--g)"><header class="ph"><h2>${esc(r.t)} \u00b7 ${esc(r.n)}</h2><button class="tg" data-a="cld">Fermer</button></header><div class="pb"><p><b>${esc(r.w)}</b>${r.ct ? ` \u00b7 ${esc(r.ct)}` : ""}<br>${r.o ? `<i>${esc(r.o)}</i><br>` : ""}${esc(r.m)}</p>${S.dp.length ? `<p><b>Pi\u00e8ces jointes :</b> ${S.dp.map((u, i) => `<a href="${esc(u)}" target="_blank" rel="noopener noreferrer">Pi\u00e8ce ${i + 1}</a>`).join(" \u00b7 ")}</p>` : ""}
<div class="fr">${o ? sel("dsv", "Service responsable", SVO, r.sv) + `<button class="bo" data-a="dact" data-o="1">Orienter</button>` : `<p><b>Service :</b> ${esc(svn(r.sv))}</p>`}</div>
<label for="drp">R\u00e9ponse au citoyen</label><textarea id="drp" rows="3" maxlength="3000">${esc(r.rp || "")}</textarea><p class="mut" data-sty="font-size:13px">Pour \u00ab Document pr\u00eat \u00e0 retirer \u00bb : indiquez le lieu et les modalit\u00e9s de retrait ci-dessus (possible seulement apr\u00e8s acceptation).</p>
<label for="dpc">Pi\u00e8ce manquante \u00e0 demander au citoyen</label><textarea id="dpc" rows="2" maxlength="1000" placeholder="Ex. Copie de la pi\u00e8ce d\u2019identit\u00e9, titre foncier\u2026">${esc(r.pd || "")}</textarea><p data-sty="margin-top:6px"><button class="bo" data-a="dact" data-s="en_attente_pieces" data-pc="1">Demander une pi\u00e8ce</button></p><label for="dmr">Motif du rejet</label><textarea id="dmr" rows="2" maxlength="1000" placeholder="Ex. Dossier hors comp\u00e9tence de la commune">${esc(r.mr || "")}</textarea><p data-sty="margin-top:6px"><button class="bo" data-a="dact" data-s="rejetee" data-mr="1">Rejeter</button></p><p data-sty="margin-top:6px">${S.sa ? "" : `<button class="bo" data-m="ntwa" data-id="${esc(r.id)}">Notifier le citoyen par WhatsApp</button>`}</p><p data-sty="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap"><button class="bo" data-a="dact" data-s="en_cours">Prendre en charge</button><button class="bo" data-a="dact" data-s="a_valider" data-r="1">Soumettre \u00e0 validation</button>${v ? `<button class="tg" data-a="dact" data-s="cloturee">Cl\u00f4turer</button><button class="bt" data-a="dact" data-s="traitee" data-r="1">Valider et cl\u00f4turer</button>` : ""}<button class="bo" data-a="dact" data-s="acceptee">Accepter la demande</button><button class="bo" data-a="dact" data-s="pret_a_retirer" data-r="1">Document pr\u00eat \u00e0 retirer</button><button class="bo" data-a="dact" data-s="redirigee" data-r="1">R\u00e9orienter vers l\u2019organisme comp\u00e9tent</button></p>
<h3 data-sty="font-size:15px">Historique</h3>${S.dh.map(h => `<div class="mut" data-sty="font-size:13px">${fdt(h.created_at)} : ${esc(RS[RC.indexOf(h.statut)] || h.statut)}${h.service ? " \u2014 " + esc(svn(h.service)) : ""}</div>`).join("") || emp("Aucun historique.")}</div></div>`;
};
const dem = f => {
  const l = D()
      .req.map((r, i) => [r, i])
      .filter(x => !f || [].concat(f).includes(x[0].t)),
    s0 = D().req.find(x => x.id == S.dd);
  return (
    (s0 ? dpanel(s0) : "") +
    (l
      .map(
        ([r, i]) =>
          `<button class="rw" data-sty="width:100%;background:none;border:0;border-top:1px solid var(--ln);text-align:left;cursor:pointer" data-a="opend" data-i="${i}"><div class="rl"><b>${esc(r.t)}</b> <span class="mut">${esc(r.n)}</span><div>${esc(r.w)} : ${esc(r.o || r.m)}</div><div class="mut" data-sty="font-size:12px">${fdt(r.c)}${r.sv ? " \u00b7 " + esc(svn(r.sv)) : ""}</div></div><span class="tg ${rc(r.st)}">${esc(r.st)}</span></button>`
      )
      .join("") || emp("Aucune demande."))
  );
};
const pubv = () => {
  const d = D();
  return (
    frm(
      sel("pc", "Type", [
        ["actualite", "Actualit\u00e9"],
        ["communique", "Communiqu\u00e9"],
        ["avis", "Avis"],
        ["evenement", "\u00c9v\u00e9nement"]
      ]) +
        sel("pr", "R\u00e9seau", ["Facebook", "Instagram", "TikTok", "YouTube"]) +
        inp("pd", "Date", "date", T) +
        sel(
          "pm",
          "M\u00e9dia joint",
          [["", "Aucun"]].concat(d.med.map(m => [m.id, (m.ty == "photo" ? "Photo : " : "Vid\u00e9o : ") + m.t]))
        )
    ) +
    `<label for="ps">Sujet (facultatif)</label><input id="ps" placeholder="Ex. inauguration du march\u00e9, hommage aux p\u00eacheurs"><p data-sty="margin-top:10px"><button class="bg" data-a="ia">G\u00e9n\u00e9rer 3 propositions avec l\u2019IA</button></p><div id="iar"></div><label for="pt">Texte po\u00e9tique</label><textarea id="pt" rows="3"></textarea><p data-sty="margin-top:10px"><button class="bo" data-a="idea">Inspirer-moi</button> <button class="bt" data-a="addpost">Ajouter en brouillon</button></p>` +
    (d.posts
      .map((p, i) => [p, i])
      .sort((a, b) => cmp(a[0], b[0]))
      .map(([p, i]) =>
        rw(
          `<div class="mut">${esc(p.r)}, ${fd(p.d)}</div>${mt(p)}<div><i>${esc(p.t)}</i></div><div data-sty="margin-top:8px"><button class="tg" data-a="copy" data-i="${i}">Copier</button> ${tag("Retirer", "delp", i)}</div>`,
          tag(PL[PS.indexOf(p.st)], "nextp", i, p.st == "valider" ? "or" : p.st == "publie" ? "ok" : p.st == "planifie" ? "bl" : "")
        )
      )
      .join("") || emp("Aucune publication. \u00c9crivez la premi\u00e8re."))
  );
};
const medv = () =>
  `<div class="g3">${pn("Ajouter une photo", "mega", frm(inp("pt2", "Titre") + fl("pf", "Fichier", '<input id="pf" type="file" accept="image/*">') + `<button class="bt" data-a="addphoto">Envoyer</button>`) + emp("Photos optimis\u00e9es automatiquement : taille r\u00e9duite, qualit\u00e9 conserv\u00e9e, localisation GPS effac\u00e9e."))}${pn("Ajouter une vid\u00e9o", "mega", frm(inp("vt", "Titre") + inp("vu", "Lien https (YouTube non r\u00e9pertori\u00e9\u2026)", "url", "", "https://") + `<button class="bt" data-a="addvideo">Ajouter</button>`))}</div><div class="g2">${
    D()
      .med.map(
        (m, i) =>
          `<div>${m.ty == "photo" ? (m.src ? `<img src="${esc(m.src)}" alt="${esc(m.t)}" loading="lazy" data-sty="width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:12px;display:block">` : '<div class="art"></div>') : `<a class="art" href="${esc(m.u)}" target="_blank" rel="noopener noreferrer">Vid\u00e9o : ouvrir le lien</a>`}<div class="rw" data-sty="border:0"><b>${esc(m.t)}</b>${tag("Retirer", "delmed", i)}</div></div>`
      )
      .join("") || emp("Aucun m\u00e9dia.")
  }</div>`;
const projl = () =>
  D()
    .proj.map((p, i) =>
      rw(
        `<b>${esc(p.titre)}</b> <span class="mut">${esc(p.localite || "")}</span><div class="mut" data-sty="font-size:13px">${esc(p.categorie)} \u00b7 ${fmt(p.budget)} FCFA</div><div class="bar" data-sty="max-width:260px"><i data-sty="width:${p.avancement}%;background:${PCOL[p.statut]}"></i></div><div data-sty="display:flex;gap:8px;align-items:center;max-width:260px"><input type="number" min="0" max="100" value="${p.avancement}" data-ch="avc" data-i="${i}" aria-label="Avancement en %" data-sty="max-width:90px">%</div>`,
        `<div data-sty="display:grid;gap:6px;justify-items:end">${tag(PSS[p.statut], "cycp", i, TC2[p.statut])}${tag(p.public ? "Visible citoyens" : "Masqu\u00e9", "pjpub", i, p.public ? "ok" : "")}${tag("Retirer", "delproj", i)}</div>`
      )
    )
    .join("") || emp("Aucun projet. Ajoutez le premier ci-dessus.");
const V = {
  dash,
  cabinet: () =>
    page(
      "Cabinet du Maire",
      tabs("cab", [
        ["agenda", "Agenda"],
        ["mail", "Courrier"]
      ]) + (S.tab.cab == "agenda" ? agenda() : mailv())
    ),
  conseil: () =>
    page(
      "Conseil Municipal",
      pn(
        "Nouvelle d\u00e9lib\u00e9ration",
        "users",
        frm(
          inp("dn", "Num\u00e9ro", "text", "", Y + "-01") +
            inp("do", "Objet") +
            inp("dj", "Date", "date", T) +
            sel("ds", "Statut", [
              ["adoptee", "Adopt\u00e9e"],
              ["projet", "Projet"],
              ["rejetee", "Rejet\u00e9e"]
            ]) +
            `<button class="bt" data-a="adddel">Ajouter</button>`
        )
      ) +
        pn(
          "D\u00e9lib\u00e9rations",
          "doc",
          D()
            .del.map((x, i) =>
              rw(
                `<b>n\u00b0${esc(x.numero)}</b> <span class="mut">${fd(x.jour)}</span><div>${esc(x.objet)}</div>`,
                `<div data-sty="display:grid;gap:6px;justify-items:end">${tag({ adoptee: "Adopt\u00e9e", projet: "Projet", rejetee: "Rejet\u00e9e" }[x.statut], "cycd", i, { adoptee: "ok", projet: "or", rejetee: "rd" }[x.statut])}${tag("Retirer", "deldel", i)}</div>`
              )
            )
            .join("") || emp("Aucune d\u00e9lib\u00e9ration enregistr\u00e9e.")
        )
    ),
  budget: () => {
    const s = stat();
    return page(
      "Budget et Finances",
      `<div class="kp">${kp("k1", "coins", "Budget annuel", s.I.budget_annuel ? fm(s.I.budget_annuel) + " FCFA" : "\u2014")}${kp("k2", "trend", "Recettes " + Y, fm(s.rec))}${kp("k3", "coins", "D\u00e9penses " + Y, fm(s.dep))}${kp("k5", "chart", "Ex\u00e9cution", s.ex + "%")}</div>` +
        pn("\u00c9volution des Finances", "trend", lineC(s.d.fin)) +
        pn(
          "Saisir un mois",
          "coins",
          frm(
            sel(
              "bm",
              "Mois",
              MOIS.map((m, i) => [i + 1, m]),
              new Date().getMonth() + 1
            ) +
              inp("br", "Recettes (FCFA)", "number", "", "0", 'min="0"') +
              inp("bd", "D\u00e9penses (FCFA)", "number", "", "0", 'min="0"') +
              `<button class="bt" data-a="addfin">Enregistrer</button>`
          ) +
            emp("Enregistrer un mois d\u00e9j\u00e0 saisi le remplace.") +
            s.d.fin
              .map((r, i) =>
                rw(
                  `<b>${MOIS[r.mois - 1]} ${r.annee}</b><div class="mut">Recettes ${fmt(r.recettes)} \u00b7 D\u00e9penses ${fmt(r.depenses)} FCFA</div>`,
                  tag("Retirer", "delfin", i)
                )
              )
              .join("")
        )
    );
  },
  projets: () =>
    page(
      "Projets et Travaux",
      pn(
        "Nouveau projet",
        "tools",
        frm(
          inp("jt", "Titre") +
            inp("jl", "Localit\u00e9") +
            sel("jc", "Cat\u00e9gorie", CAT) +
            sel(
              "js",
              "Statut",
              PST.map(k => [k, PSS[k]])
            ) +
            inp("ja", "Avancement (%)", "number", "0", "", 'min="0" max="100"') +
            inp("jb", "Budget (FCFA)", "number", "0", "", 'min="0"') +
            sel("jdm", "Domaine", [["", "\u2014"]].concat(DOM)) +
            sel("jaj", "Adjoint responsable", [["", "Aucun"]].concat(aopts())) +
            inp("jd1", "D\u00e9but", "date") +
            inp("jd2", "Fin pr\u00e9vue", "date") +
            inp("jfi", "Financement") +
            inp("jre", "Responsable") +
            inp("jds", "Description") +
            inp("jy", "Latitude", "text", "", "14.2000") +
            inp("jx", "Longitude", "text", "", "-16.7000") +
            `<button class="bo" data-a="geo">Ma position</button><button class="bt" data-a="addproj">Ajouter</button>`
        )
      ) + pn("Projets", "tools", projl())
    ),
  civil: () => page("\u00c9tat Civil", pn("Demandes d\u2019\u00e9tat civil", "file", dem("\u00c9tat civil"))),
  citoyens: () => page("Citoyens", pn("Demandes des citoyens", "user", dem(""))),
  territoire: () =>
    page(
      "Territoire & Foncier",
      pn("Carte de la commune", "map", mapP(1)) +
        pn(
          "Projets localis\u00e9s",
          "tools",
          D()
            .proj.filter(p => p.lat != null)
            .map(p =>
              rw(
                `<b>${esc(p.titre)}</b><div class="mut">${esc(p.localite || "")}</div>`,
                `<span class="tg" data-sty="cursor:default">${PSL[p.statut]}</span>`
              )
            )
            .join("") || emp("Ajoutez la latitude et la longitude de vos projets pour les voir sur la carte.")
        )
    ),
  rapports: () => {
    const s = stat();
    return page(
      "Rapports et Statistiques",
      `<p class="noprint"><button class="bt" data-a="print">Imprimer / PDF</button> <button class="bo" data-a="csv" data-k="projets">Exporter les projets (CSV)</button> <button class="bo" data-a="csv" data-k="demandes">Exporter les demandes (CSV)</button></p><div class="kp">${kp("k1", "users", "Population", fmt(s.I.population))}${kp("k2", "tools", "Projets", s.pr.length)}${kp("k3", "mail", "Demandes", s.d.req.length)}${kp("k4", "doc", "D\u00e9lib\u00e9rations " + Y, s.dels)}${kp("k5", "coins", "Ex\u00e9cution budget", s.ex + "%")}</div><div class="g3">${pn("\u00c9volution des Finances", "trend", lineC(s.d.fin))}${pn("Avancement des Projets", "pie", progP(s))}${pn("R\u00e9partition des Investissements", "chart", invP(s))}</div>`
    );
  },
  comm: () =>
    page(
      "Communication",
      tabs("com", [
        ["pub", "Publications"],
        ["med", "M\u00e9diath\u00e8que"]
      ]) + (S.tab.com == "pub" ? pubv() : medv())
    ),
  params: () => {
    const I = S.ind,
      up = (k, l, f) =>
        `<div class="rw"><div class="rl"><b>${l}</b><div>${url(k) ? `<img class="th" src="${esc(url(k))}" alt="${l}">` : '<span class="mut">Aucune image</span>'}</div></div><div data-sty="display:grid;gap:6px"><input type="file" id="${f}" accept="image/*" aria-label="${l}"><button class="bo" data-a="upimg" data-k="${k}" data-f="${f}">Envoyer</button></div></div>`;
    return page(
      "Param\u00e8tres",
      pn(
        "Indicateurs de la commune",
        "gear",
        frm(
          inp("pp", "Population", "number", I.population || 0) +
            inp("pg", "Croissance (%)", "number", I.croissance || 0, "", 'step="0.1"') +
            inp("pv", "Villages et localit\u00e9s", "number", I.villages || 0) +
            inp("pm", "M\u00e9nages recens\u00e9s", "number", I.menages || 0) +
            inp("pa", "Agents municipaux", "number", I.agents || 0) +
            inp("pb", "Budget annuel (FCFA)", "number", I.budget_annuel || 0) +
            inp("psl", "Slogan", "text", I.slogan || "") +
            inp("pdv", "Devise", "text", I.devise || "") +
            inp("ptl", "T\u00e9l\u00e9phone de la mairie", "text", I.contact_tel || "") +
            inp("pad", "Adresse de la mairie", "text", I.contact_adresse || "") +
            inp("pla", "Latitude du centre", "text", I.centre_lat ?? "") +
            inp("plo", "Longitude du centre", "text", I.centre_lng ?? "") +
            inp("pz", "Zoom de la carte", "number", I.zoom || 11, "", 'min="3" max="18"') +
            inp("pdp", "D\u00e9partement", "text", I.departement || "") +
            inp("prg", "R\u00e9gion", "text", I.region || "") +
            inp("ppy", "Pays", "text", I.pays || "") +
            `<button class="bt" data-a="saveind">Enregistrer</button>`
        )
      ) +
        pn(
          "Images",
          "gear",
          up("blason", "Blason", "ub") + up("photo_maire", "Photo du Maire", "um") + up("bandeau", "Bandeau d\u2019accueil", "uo")
        )
    );
  }
};
