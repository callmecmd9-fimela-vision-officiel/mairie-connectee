-- LOT 8 : durcissement RLS de public.paiements_taxes (constat de l'audit du 2026-11-24, base de production en lecture seule).
-- Constat : l'ancienne politique d'insertion « paiements_creer » n'impose pas statut='en_attente' ; or les politiques s'additionnent (OR)
-- et le privilège INSERT couvre la colonne statut : un compte du personnel pourrait créer pour lui-même une ligne déjà « paye » (faux reçu).
-- Correctif : même condition qu'avant (commune de l'utilisateur, citoyen_id = soi) + statut initial obligatoire. Idempotent. NON appliqué.
drop policy if exists paiements_creer on public.paiements_taxes;
create policy paiements_creer on public.paiements_taxes for insert to authenticated
 with check(commune_id=(select public.org_commune()) and citoyen_id=(select auth.uid()) and statut='en_attente');
-- Contrôle : toute table de paiement/notification/état civil doit avoir la RLS active et aucun droit pour anon.
-- select c.relname,c.relrowsecurity,has_table_privilege('anon','public.'||c.relname,'select') from pg_class c join pg_namespace n on n.oid=c.relnamespace
--  where n.nspname='public' and c.relname in('actes_etat_civil','actes_copies','paiements_taxes','tarifs_demarches','notifications_whatsapp');
