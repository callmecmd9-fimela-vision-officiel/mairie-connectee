# Procédure de déploiement — circuit des demandes, guichet, suivi public (2026-11-25)

Migrations concernées (statut `proposed` dans `PRODUCTION_VERSION_MAP.md`) : `20261202001600`, `001700`, `001800`, `001900`, `002000`.
Fichiers : `supabase/APPLY_ALL_MIGRATIONS.sql` (une seule transaction), `supabase/VERIFY_ALL.sql` (lecture seule).

## 1. Sauvegarde
1. Lancer le workflow GitHub « Sauvegarde chiffrée de la base » (`db-backup.yml`, manuellement) et attendre la fin ; ou `pg_dump` avec la chaîne « Session pooler ».
2. Noter l'identifiant de la sauvegarde (nom de l'artefact) avant de continuer.

## 2. Appliquer
1. Supabase > SQL Editor (projet `aiqegpijisspankpkwfj`) : coller `APPLY_ALL_MIGRATIONS.sql` en entier et exécuter.
2. Le fichier commence par `BEGIN;` et se termine par `COMMIT;` (un seul de chaque). Ne pas le découper.
3. Prérequis déjà en production : `20261202001500` (FK `paiements_taxes.citoyen_id`) et les helpers `private.my_role()`, `private.my_commune()`, `private.hors_maintenance()`, `private.audit()`.

## 3. Vérifier
1. Exécuter `VERIFY_ALL.sql` : toutes les lignes doivent afficher `existe` (les `manquant` sont triés en premier).
2. Propriétaire de `cloturer_deliberation` (ligne « propriétaire postgres » de VERIFY_ALL ; requête de contrôle direct) :
   `select r.rolname from pg_proc p join pg_roles r on r.oid = p.proowner where p.proname = 'cloturer_deliberation' and p.pronamespace = 'public'::regnamespace;` → `postgres`.
3. Tester les RPC par SELECT, dans une transaction annulée (rien n'est conservé) :
   - `begin; select * from public.suivi_public('FIM-2026-000000', '770000000'); rollback;` → 0 ligne (jamais d'erreur ; ~0,5 s de délai).
   - `begin; select public.encaisser_demande(null::uuid, 1, 'guichet', 'TEST'); rollback;` → erreur « Authentification requise » (28000) : la fonction répond et refuse sans session.
   - `begin; select public.retirer_demande(null::uuid, 'Test', '12345'); rollback;` → même refus (28000).
4. Politiques : `select policyname, cmd, permissive from pg_policies where tablename in ('demandes', 'demandes_historique') order by 1;` → `demandes_guichet` et `demandes_historique_guichet` (SELECT, PERMISSIVE), `demandes_personnel` inchangée.

## 4. Edge Function `sa-admin`
1. Le dépôt contient déjà le rôle `conseiller` dans `ROLES` ; la version déployée attendue est **v18** (`verify_jwt` = true, redéployée le 2026-11-25).
2. Si le tableau de bord Supabase affiche une version antérieure à v18 : `supabase functions deploy sa-admin --project-ref aiqegpijisspankpkwfj`. Sinon rien à faire.
3. Tester : console Super Admin > création d'un compte de rôle « Conseiller municipal ».

## 5. Tester l'écran Caisse (compte finances)
1. Avec un compte `secretariat` : Administration > Guichet > Dépôt : créer une demande payante (le numéro `FIM-AAAA-NNNNNN` s'affiche) ; imprimer le reçu.
2. Avec un compte `finances` : Administration > Guichet > Caisse : la demande au statut `a_payer` doit apparaître (toute la commune, quel que soit le service).
3. Encaisser : quittance `QUIT-AAAA-NNNNNN`, redirection vers `quittance.html`.
4. Page `/suivi.html` : numéro + téléphone → statut « Payée ».

## 6. Consigner
Noter la date et l'heure d'application, la sauvegarde utilisée et le résultat de `VERIFY_ALL.sql` dans `TASKS.md` ; passer les lignes de `PRODUCTION_VERSION_MAP.md` de `proposed` à `appliquée` avec la version inscrite dans l'historique.

## En cas d'erreur dans APPLY_ALL
- La transaction `BEGIN ... COMMIT` annule **tout** : à la première erreur, rien n'est conservé (l'éditeur SQL affiche l'erreur et la transaction est abandonnée). Aucun nettoyage n'est nécessaire.
- Lire le message (ligne, code SQLSTATE), corriger la cause (ex. prérequis manquant : `private.my_role()`), puis relancer le fichier entier. Les migrations sont idempotentes.
- Cas fréquents : `permission denied` (utiliser le rôle `postgres` de l'éditeur SQL) ; `relation ... does not exist` (une migration antérieure manque : vérifier `PRODUCTION_VERSION_MAP.md`) ; verrou long sur `demandes` (relancer hors heures de pointe).
- Si l'éditeur a été fermé en cours d'exécution, relancer `VERIFY_ALL.sql` : si tout est `manquant`, la transaction a bien été annulée.

## Rollback (après COMMIT)
Aucune migration n'est destructive : elles ajoutent des colonnes, tables, fonctions, vues et politiques, et élargissent la contrainte de statut. Pour revenir en arrière :
1. **Rapide (front seul)** : retirer le sous-menu Guichet (ne pas déployer `js/guichet.js`) et le lien « Suivre ma demande » ; la base peut rester en l'état.
2. **Politiques** : `drop policy if exists demandes_guichet on public.demandes; drop policy if exists demandes_historique_guichet on public.demandes_historique;` (`demandes_personnel` n'a jamais été modifiée).
3. **RPC** : `drop function if exists public.retirer_demande(uuid, text, text); drop function if exists public.encaisser_demande(uuid, numeric, text, text); drop function if exists public.suivi_public(text, text);`
4. **Objets de données** (uniquement si aucune donnée réelle n'a été saisie ; sinon les conserver) : `drop view if exists public.v_suivi_public; drop table if exists public.suivi_tokens, public.registre_retraits, public.quittances, public.demandes_historique;` puis supprimer les triggers `trg_demandes_num_suivi`, `trg_demandes_log_statut`, `trg_demandes_garde_workflow`, `trg_ptx_num_quittance` et leurs fonctions.
5. **Restauration complète** : en dernier recours, restaurer la sauvegarde de l'étape 1 (voir `docs/SAUVEGARDE.md`). Les colonnes ajoutées (`demandes.num_suivi`, `montant_du`, `lieu_retrait`, `paiements_taxes.num_quittance`, `agent_id`, `ref_recu`) sont inoffensives et peuvent rester.
